# Melate ingestion patch for `lab-unified`

This patch adds a domain-specific ingestion layer under `eso/melate/` instead of
forcing lottery data through the crypto/Binance builders.

## Sources

1. **Lotería Nacional** historical Melate CSV is the identity authority for draw
   number/date/main numbers/additional number/jackpot.
2. **resultados.melate-e.com** is a secondary source for historical prize-tier
   counts and individual prizes. Its rows are accepted only if its winning
   combination matches the official draw exactly.

Every raw response is intended to be persisted with URL, retrieval timestamp and
SHA-256. Secondary prize data is never silently promoted to official data.

## Install into the branch

Copy `eso/melate/` and `scripts/build_melate_dataset.py` into the repository.
The code uses dependencies already present in the project (`pandas`, `requests`)
and requires a parquet engine (`pyarrow` or `fastparquet`) only for parquet output.

## Build

```bash
python scripts/build_melate_dataset.py \
  --official-file /path/to/Melate.csv \
  --from-contest 2800 \
  --to-contest 4265 \
  --output data/melate/canonical \
  --raw data/melate/raw
```

Omit `--official-file` to download the current official CSV directly.

Start with a bounded range (for example 2800..4265). Once coverage and parser
stability are verified, widen the historical range.

## Canonical outputs

- `draws.parquet` / `draws.csv`
- `prize_tiers.parquet` / `prize_tiers.csv`
- `coverage.csv`
- `quarantine.csv` if secondary-source identities fail reconciliation
- `manifest.json`

The crypto `eso/data/loader.py` remains untouched. Modeling code should consume
canonical Melate DataFrames and build lottery-specific features afterwards.
